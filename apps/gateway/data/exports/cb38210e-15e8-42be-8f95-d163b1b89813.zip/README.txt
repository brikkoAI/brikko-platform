Архив с данными вашего аккаунта Brikko (152-ФЗ ст. 14, GDPR Art. 20).

Файлы:

  account.json        — настройки аккаунта (без флагов внутренних UI)
  user.json           — профиль пользователя (без password_hash и TOTP-секретов)
  keys.json           — список API-ключей (prefix, name, scope, status). Полные
                        ключи и хеши НЕ выгружаются — мы их не храним и они уже
                        известны вам по ответам /v1/keys.
  transactions.json   — все ledger-транзакции (top-up / charge / refund / др.)
  usage_events.json   — все запросы к моделям (без зашифрованного prompt'а;
                        для расследований обращайтесь в support@brikko.ru).
  audit_log.json      — журнал security-событий по вашему юзеру.
  sessions.json       — список выпущенных сессий (без секретов refresh-token).

Время снимка: см. поле requested_at в data-export-info.json.

Если в архиве чего-то не хватает — support@brikko.ru.
